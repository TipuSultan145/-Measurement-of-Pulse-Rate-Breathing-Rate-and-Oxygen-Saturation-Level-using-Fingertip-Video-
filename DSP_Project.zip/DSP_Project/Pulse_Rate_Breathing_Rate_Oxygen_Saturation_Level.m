close all
clear all
 
x = VideoReader('Subject1_0.mp4'); % put the title of the video in here.
y = read(x);
 
for img = 1:x.NumberOfFrames; % Measure the average intense per frame for red channel 
    filename = strcat('frame',num2str(img),'.jpg');
    b = read(x, img);
    rc = b(:,:,1);
    E(img) = mean(mean(rc));
end
 
for img = 1:x.NumberOfFrames; % Measure the average intense per frame for blue channel
    filename = strcat('frame',num2str(img),'.jpg');
    b = read(x, img);
   
    rc = b(:,:,3);
    L(img) = mean(mean(rc));
end
 
 m = 1:length(E);
 j = m/x.FrameRate;
 subplot(2,1,1)
 
 Z = E - mean(E); 
 [B A] = butter(3, .015); %Third order butter worth filter
 F = filter(B,A,Z);
 [PkAmpB, PkTimeB] = findpeaks(F, 'MinPeakDistance', 30);
 findpeaks(F,j , 'MinPeakDistance', 1);
 xlabel('Time(s)','FontSize',10);
 ylabel('Amplitude','FontSize',10);
 title('Breathing Rate')
 subplot(2,1,2)
 
 b = 1/10*ones(10,1);
 out1 = filter(b,1,Z); % Moving average filter
 [PkAmpP, PkTimeP] = findpeaks(out1, 'MinPeakDistance', 15); % Peak piking
 findpeaks(out1,j,  'MinPeakDistance', .5);
 xlabel('Time(s)','FontSize',10);
 ylabel('Amplitude','FontSize',10);
 title('Pulse Rate')
 
 AC_red = var(E);
 DC_red = mean(E);
 AC_IR = var(L);
 DC_OR = mean(L);
 R = ((AC_red/DC_red)/(AC_IR/DC_OR));
 SpO2 = -45.060*R*R + 30.354*R+94.845 % Oxygen saturation level
 Pulse_rate = round((length(PkTimeP)/x.Duration)*60) % Calculate the pulse rate
 Breathing_rate = round((length(PkTimeB)/x.Duration)*60) % Calculate the breathing       
 rate
