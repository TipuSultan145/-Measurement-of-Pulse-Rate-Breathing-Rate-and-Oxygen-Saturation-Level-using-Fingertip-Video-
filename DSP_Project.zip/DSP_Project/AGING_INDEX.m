% Main code block

close all;
clear all;

% Reading video
vid = VideoReader('Subject1_0.mp4');
frames_count = vid.NumFrames;
frame_rate = vid.FrameRate;
duration = vid.Duration;

% Separating red channel
for img = 1:frames_count
    frames = read(vid, img);
    red(img) = mean(mean(frames(:,:,1)));
end

% Separating blue channel
for img = 1:frames_count
    frames = read(vid, img);
    Blue(img) = mean(mean(frames(:,:,3)));
end

%% Main function execution
videoPath = 'Subject1_0.mp4'; % Replace with your actual video path
agingIndex = process_video(videoPath);

% Output the aging index
if ~isempty(agingIndex)
    fprintf('Aging Index: %.2f\n', agingIndex);
else
    disp('Cannot calculate Aging Index.');
end

% Function definitions (move all functions below)

function normalizedSignal = normalize_signal(signal)
    minSignalValue = min(signal);
    maxSignalValue = max(signal);
    normalizedSignal = (signal - minSignalValue) / (maxSignalValue - minSignalValue);
end

function secondDerivative = second_derivative(signal, windowLength, polyOrder)
    if mod(windowLength, 2) == 0
        windowLength = windowLength + 1;
    end
    if windowLength <= polyOrder
        windowLength = polyOrder + 2;
    end
    secondDerivative = sgolayfilt(signal, polyOrder, windowLength, [], 2);
end

function relevantPeaks = identify_relevant_peaks(signal, distance, prominence)
    if nargin < 2
        distance = 3;
    end
    if nargin < 3
        prominence = 0.00001;
    end
    % Find peaks in the positive part of the signal
    [peaks1, locs1] = findpeaks(signal, 'MinPeakDistance', distance, 'MinPeakProminence', prominence);
    % Find peaks in the negative part of the signal
    [peaks2, locs2] = findpeaks(-signal, 'MinPeakDistance', distance, 'MinPeakProminence', prominence);
    
    % Combine and sort peaks if they have compatible dimensions
    if ~isempty(locs1) && ~isempty(locs2)
        allPeaks = sort([locs1; locs2]);
    elseif ~isempty(locs1)
        allPeaks = locs1;
    else
        allPeaks = locs2;
    end
    relevantPeaks = allPeaks;
end

function agingIndex = calculate_aging_index(ppgSignal, derivativePeaks)
    disp('Calculating Aging Index...')
    disp(['Length of ppgSignal: ' num2str(length(ppgSignal))])
    disp(['Number of derivativePeaks: ' num2str(length(derivativePeaks))])

    if numel(derivativePeaks) < 5
        disp('Cannot calculate Aging Index: Insufficient peaks.');
        agingIndex = [];
        return;
    end
    
    ppgPeaks = derivativePeaks - 1;
    disp(['ppgPeaks: ', num2str(ppgPeaks')])
    
    % Check if `ppgPeaks` indices are within the range of `ppgSignal`
    if any(ppgPeaks <= 0 | ppgPeaks > length(ppgSignal))
        disp('Error: `ppgPeaks` contains out-of-bounds indices.')
        agingIndex = [];
        return;
    end
    
    [~, a] = max(ppgSignal(ppgPeaks));
    subsequentPeaks = ppgPeaks(ppgPeaks > a);
    
    % Further debug output
    disp(['Length of subsequentPeaks: ' num2str(length(subsequentPeaks))])
    disp(['subsequentPeaks: ', num2str(subsequentPeaks')])

    if numel(subsequentPeaks) < 4
        disp('Cannot calculate Aging Index: Insufficient subsequent peaks.');
        agingIndex = [];
        return;
    end

    % Find subsequent peaks b, c, d, e
    sortedSubsequentPeaks = sort(subsequentPeaks);
    b = sortedSubsequentPeaks(1);
    c = sortedSubsequentPeaks(2);
    d = sortedSubsequentPeaks(3);
    e = sortedSubsequentPeaks(4);

    % Calculate the Aging Index
    agingIndex = (ppgSignal(b) - ppgSignal(c) - ppgSignal(d) - ppgSignal(e)) / ppgSignal(a);

    % Print identified points for verification
    disp(['Identified points on PPG signal: a=' num2str(a) ', b=' num2str(b) ', c=' num2str(c) ', d=' num2str(d) ', e=' num2str(e)]);
    disp(['Aging Index calculation: ((' num2str(ppgSignal(b)) ' - ' num2str(ppgSignal(c)) ' - ' num2str(ppgSignal(d)) ' - ' num2str(ppgSignal(e)) ') / ' num2str(ppgSignal(a)) ') = ' num2str(agingIndex)]);
end

function agingIndex = process_video(videoPath)
    try
        video = VideoReader(videoPath);
        if ~isfile(videoPath)
            error('Error opening file');
        end
        frameCount = video.NumFrames;
        fps = video.FrameRate;
        rChannelAvg = zeros(1, frameCount);
        for i = 1:frameCount
            frame = read(video, i);
            rChannelAvg(i) = mean(frame(:, :, 1), 'all');
        end
        normalizedRChannel = normalize_signal(rChannelAvg);
        ppg2ndDerivative = second_derivative(normalizedRChannel, 21, 2);
        peaks = identify_relevant_peaks(ppg2ndDerivative);
        agingIndex = calculate_aging_index(normalizedRChannel, peaks);
        figure;
        subplot(2, 1, 1);
        plot(normalizedRChannel, 'LineWidth', 1.5);
        title('Normalized PPG Signal');
        xlabel('Frame');
        ylabel('Normalized Intensity');
        subplot(2, 1, 2);
        plot(ppg2ndDerivative, 'LineWidth', 1.5);
        hold on;
        scatter(peaks, ppg2ndDerivative(peaks), 'r', 'filled');
        hold off;
        title('Second Derivative of Signal with Peaks');
        xlabel('Frame Count');
        ylabel('Second Derivative Peak');
        legend('Second Derivative', 'Peaks');
        saveas(gcf, 'output.png');
        close(gcf);
        return;
    catch ex
        disp(['An error occurred: ' ex.message]);
        agingIndex = [];
        return;
    end
end
